//driver.h
#include <iostream>
#include <string>

using namespace std;


bool librarian_login();
bool patron_login();
void login();
void main_menu();
void find_book();
void view_all_books();
void find_by_title(string);
void find_by_author(string);
bool patron_login();
bool librarian_login();
